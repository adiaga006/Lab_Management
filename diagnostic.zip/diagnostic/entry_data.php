<?php
include('./constant/layout/head.php');
include('./constant/layout/header.php');
include('./constant/layout/sidebar.php');
include('./constant/connect.php');

$caseStudyId = $_GET['case_study_id'];
$groupId = $_GET['group_id'];

// Fetch group name
$sql = "SELECT group_name FROM groups WHERE group_id = '$groupId'";
$groupResult = $connect->query($sql);
$group = $groupResult->fetch_assoc();

// Fetch case study start date
$caseStudySql = "SELECT start_date FROM case_study WHERE case_study_id = '$caseStudyId'";
$caseStudyResult = $connect->query($caseStudySql);
$caseStudy = $caseStudyResult->fetch_assoc();
$startDate = $caseStudy ? $caseStudy['start_date'] : null;

// Fetch and organize entry data by date with specified order
$entrySql = "SELECT * FROM entry_data WHERE case_study_id = '$caseStudyId' AND group_id = '$groupId'
             ORDER BY 
             CASE
                WHEN treatment_name = 'Negative control' THEN 1
                WHEN treatment_name = 'Positive control' THEN 2
                WHEN treatment_name = 'Treatment 1 (1,000 ppm_Prototype 13A)' THEN 3
                WHEN treatment_name = 'Treatment 2 (2,000 ppm_Prototype 13A)' THEN 4
                WHEN treatment_name = 'Treatment 3 (1,000 ppm_AviPlus Aqua)' THEN 5
                WHEN treatment_name = 'Treatment 4 (2,000 ppm_AviPlus Aqua)' THEN 6
                ELSE 7
             END,
             lab_day ASC, 
             created_at ASC";
$entryResult = $connect->query($entrySql);
$entries = [];
while ($entry = $entryResult->fetch_assoc()) {
    $entries[] = $entry;
}

// Group entries by treatment and day
function groupEntriesByTreatmentAndDay($entries) {
    $grouped = [];
    foreach ($entries as $entry) {
        $grouped[$entry['treatment_name']][$entry['product_application']][$entry['lab_day']][] = $entry;
    }
    return $grouped;
}

$groupedEntries = groupEntriesByTreatmentAndDay($entries);
?>

<style>
    /* CSS for uniform borders */
    .table-bordered th,
    .table-bordered td {
        border: 2px solid #333 !important; /* Uniform 2px border for all cells */
        text-align: center;
        vertical-align: middle;
    }
</style>


<div class="page-wrapper">
    <div class="row page-titles">
        <div class="col-md-10 align-self-center">
            <h3 class="text-primary">
                Data for Case Study ID: <?php echo htmlspecialchars($caseStudyId); ?> - Group: <?php echo htmlspecialchars($group['group_name']); ?>
            </h3>
        </div>
    </div>

    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h4>Entries for Group: <?php echo htmlspecialchars($group['group_name']); ?></h4>

                <div class="table-responsive m-t-20">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Treatment Name</th>
                                <th>Product Application</th>
                                <th>Day</th>
                                <th>Reps</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($groupedEntries as $treatmentName => $products): ?>
                                <?php $firstTreatmentRow = true; ?>
                                <?php foreach ($products as $productApplication => $days): ?>
                                    <?php $firstProductRow = true; ?>
                                    <?php foreach ($days as $day => $entries): ?>
                                        <?php $firstDayRow = true; $repCount = 1; ?>
                                        <?php foreach ($entries as $entry): ?>
                                            <tr>
                                                <!-- Display Treatment Name only once per treatment group -->
                                                <?php if ($firstTreatmentRow): ?>
                                                    <td rowspan="<?php echo array_sum(array_map('count', array_column($products, $day))); ?>" style="font-weight: bold;">
                                                        <?php echo htmlspecialchars($treatmentName); ?>
                                                    </td>
                                                    <?php $firstTreatmentRow = false; ?>
                                                <?php endif; ?>

                                                <!-- Display Product Application only once per product group within the treatment -->
                                                <?php if ($firstProductRow): ?>
                                                    <td rowspan="<?php echo array_sum(array_map('count', $days)); ?>">
                                                        <?php echo htmlspecialchars($productApplication); ?>
                                                    </td>
                                                    <?php $firstProductRow = false; ?>
                                                <?php endif; ?>

                                                <!-- Display Day only once per day group within the product application -->
                                                <?php if ($firstDayRow): ?>
                                                    <td rowspan="<?php echo count($entries); ?>">
                                                        <?php echo date('d-m-Y', strtotime($day)); ?>
                                                    </td>
                                                    <?php $firstDayRow = false; ?>
                                                <?php endif; ?>

                                                <!-- Display Reps and Action -->
                                                <td><?php echo $repCount++; ?></td>
                                                <td>
                                                    <button class='btn btn-warning btn-sm edit-entry' data-id='<?php echo $entry['entry_data_id']; ?>'>
                                                        <i class='fa fa-pencil'></i>
                                                    </button>
                                                    <button class='btn btn-danger btn-sm delete-entry' data-id='<?php echo $entry['entry_data_id']; ?>'>
                                                        <i class='fa fa-trash'></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endforeach; ?>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include jQuery, Bootstrap, and Bootstrap Datepicker -->
<script src="assets/js/lib/jquery/jquery.min.js"></script> 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />

<script>
$(document).ready(function () {
    // Initialize Datepicker
    $('.datepicker').datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
        todayHighlight: true
    });

    // Edit entry data modal
    $(document).on('click', '.edit-entry', function() {
        const entryId = $(this).data('id');
        $.post('php_action/get_entry_data.php', { entry_data_id: entryId }, function(response) {
            if (response.success) {
                $('#editEntryId').val(response.data.entry_data_id);
                $('#editTreatmentName').val(response.data.treatment_name);
                $('#editProductApplication').val(response.data.product_application);
                $('#editSurvivalSample').val(response.data.survival_sample);
                $('#editLabDay').val(response.data.lab_day.split('-').reverse().join('-'));
                $('#editDataModal').modal('show');
            } else {
                alert('Error fetching entry data.');
            }
        }, 'json');
    });

    // Update entry data
    $('#editDataForm').on('submit', function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        $.post('php_action/edit_entry_data.php', formData, function(response) {
            if (response.success) {
                alert('Entry updated successfully!');
                $('#editDataModal').modal('hide');
                location.reload();
            } else {
                alert('Failed to update entry.');
            }
        }, 'json');
    });

    // Delete entry data
    $(document).on('click', '.delete-entry', function() {
        const entryId = $(this).data('id');
        if (confirm('Are you sure you want to delete this entry?')) {
            $.post('php_action/remove_entry_data.php', { entry_data_id: entryId }, function(response) {
                if (response.success) {
                    alert('Entry deleted successfully!');
                    location.reload();
                } else {
                    alert('Failed to delete entry.');
                }
            }, 'json');
        }
    });
});
</script>

<!-- Edit Data Modal -->
<div id="editDataModal" class="modal fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form id="editDataForm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Entry Data</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="entry_data_id" id="editEntryId">
                    <div class="form-group">
                        <label>Treatment Name</label>
                        <input type="text" name="treatment_name" class="form-control" id="editTreatmentName" readonly>
                    </div>
                    <div class="form-group">
                        <label>Product Application</label>
                        <input type="text" name="product_application" class="form-control" id="editProductApplication" readonly>
                    </div>
                    <div class="form-group">
                        <label>Survival Sample</label>
                        <input type="number" name="survival_sample" class="form-control" id="editSurvivalSample" required>
                    </div>
                    <div class="form-group">
                        <label>Day</label>
                        <input type="text" name="lab_day" class="form-control datepicker" id="editLabDay" required maxlength="10">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Save Changes</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php include('./constant/layout/footer.php'); ?>
