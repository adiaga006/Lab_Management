<?php
include('./constant/layout/head.php');
include('./constant/layout/header.php');
include('./constant/layout/sidebar.php');
include('./constant/connect.php');

// Fetch the `case_study_id` from the URL
$caseStudyId = isset($_GET['case_study_id']) ? $_GET['case_study_id'] : 0;
if (!$caseStudyId) {
    die("Error: Missing case_study_id in URL");
}

// Query case study details
$sql = "SELECT start_date, phases, num_reps FROM case_study WHERE case_study_id = ?";
$stmt = $connect->prepare($sql);
$stmt->bind_param("s", $caseStudyId);
$stmt->execute();
$result = $stmt->get_result();
$caseStudy = $result->fetch_assoc();
$stmt->close();

if (!$caseStudy) {
    die("Error: Case study not found.");
}

$startDate = $caseStudy['start_date'];
$numReps = $caseStudy['num_reps'];
$phasesJson = $caseStudy['phases'];
$phases = json_decode($phasesJson, true);

if (!is_array($phases)) {
    die("Error: Invalid or missing phases data.");
}
if ($numReps <= 0) {
    die("Error: Number of reps cannot be zero or less.");
}

// Calculate phase dates
$currentDate = new DateTime($startDate);
foreach ($phases as &$phase) {
    $phase['start_date'] = $currentDate->format('Y-m-d');
    $currentDate->modify("+{$phase['duration']} days");
    $phase['end_date'] = $currentDate->modify("-1 day")->format('Y-m-d');
    $currentDate->modify("+1 day");
}

// Query entry_data for all treatments
$sql = "SELECT treatment_name, survival_sample, feeding_weight, lab_day FROM entry_data WHERE case_study_id = ?";
$stmt = $connect->prepare($sql);
$stmt->bind_param("s", $caseStudyId);
$stmt->execute();
$result = $stmt->get_result();
$entries = [];
while ($row = $result->fetch_assoc()) {
    $entries[] = $row;
}
$stmt->close();

// Helper function to calculate survival rate
function calculateSurvivalRate($startSamples, $endSamples) {
    if ($startSamples > 0 && $endSamples > 0) {
        return ($endSamples / $startSamples) * 100;
    }
    return null;
}

// Process data for treatments and calculate metrics
$treatmentData = [];
$feedingResults = [];
$survivalResults = [
    'Pre-challenge' => [],
    'Post-challenge' => []
];

// Group data by treatment
foreach ($entries as $entry) {
    $treatmentName = $entry['treatment_name'];
    $labDay = $entry['lab_day'];

    if (!isset($treatmentData[$treatmentName])) {
        $treatmentData[$treatmentName] = ['feeding_weight' => [], 'survival_sample' => []];
    }

    if ($entry['feeding_weight'] !== null) {
        $treatmentData[$treatmentName]['feeding_weight'][] = $entry['feeding_weight'];
    }

    if ($entry['survival_sample'] !== null) {
        $treatmentData[$treatmentName]['survival_sample'][$labDay] = $entry['survival_sample'];
    }
}

// Calculate total feeding weight
foreach ($treatmentData as $treatmentName => $data) {
    $totalFeeding = array_sum($data['feeding_weight']);
    $feedingResults[] = [
        'treatment_name' => $treatmentName,
        'total_feeding_weight' => round($totalFeeding, 2),
    ];
}

// Calculate survival rate for each phase
foreach ($phases as $phase) {
    if (!in_array($phase['name'], ['Pre-challenge', 'Post-challenge'])) {
        continue; // Skip irrelevant phases
    }

    foreach ($treatmentData as $treatmentName => $data) {
        $startSurvival = $data['survival_sample'][$phase['start_date']] ?? null;
        $endSurvival = $data['survival_sample'][$phase['end_date']] ?? null;

        if ($startSurvival !== null && $endSurvival !== null) {
            $survivalRate = calculateSurvivalRate($startSurvival, $endSurvival);

            if ($survivalRate !== null) {
                $survivalResults[$phase['name']][] = [
                    'treatment_name' => $treatmentName,
                    'survival_rate' => round($survivalRate, 2),
                ];
            }
        }
    }
}
// Prepare chart data for "Pre-challenge" phase
$preChallengeData = [];
foreach ($survivalResults['Pre-challenge'] as $result) {
    $preChallengeData[] = [
        'treatment_name' => $result['treatment_name'],
        'survival_rate' => $result['survival_rate']
    ];
}

// Prepare data for SVG
$preChallengeLabels = array_column($preChallengeData, 'treatment_name');
$preChallengeRates = array_column($preChallengeData, 'survival_rate');
$maxRate = max($preChallengeRates); // To scale the chart
?>
<div class="page-wrapper">
    <div class="container-fluid">
        <!-- Table for feeding weight -->
        <div class="card">
            <div class="card-body">
                <h4 style="color: black;">Total Feed Consumption</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Treatment Name</th>
                                <th>Total Feed Consumption</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($feedingResults as $result): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($result['treatment_name']); ?></td>
                                    <td><?php echo $result['total_feeding_weight']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Table for survival rate -->
        <div class="card">
            <div class="card-body">
                <h4 style="color: black;">Survival Rate: Pre-challenge</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Treatment Name</th>
                                <th>Survival Rate (%)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($survivalResults['Pre-challenge'] as $result): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($result['treatment_name']); ?></td>
                                    <td><?php echo $result['survival_rate']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Column Chart -->
        <div class="card" style="margin-top: 40px;">
            <div class="card-body">
                <h4 style="color: black; text-align: center; margin-bottom: 20px;">
                    Survival Rate of Shrimp on Day 21 of Pre-challenge Phase
                </h4>
                <div style="display: flex; justify-content: center; align-items: flex-end; height: 300px; margin-top: 20px; border: 1px solid black; width: 100%; max-width: 800px; margin-left: auto; margin-right: auto; padding: 20px;">
                    <?php
                    // Generate bars for the column chart
                    $maxRate = max(array_column($survivalResults['Pre-challenge'], 'survival_rate'));
                    foreach ($survivalResults['Pre-challenge'] as $result) {
                        $height = ($result['survival_rate'] / $maxRate) * 200; // Adjusted bar height scaling
                        $treatment = htmlspecialchars($result['treatment_name']);
                        $rate = $result['survival_rate'];
                        $barColor = ($rate >= 50) ? 'green' : 'red'; // Color logic
                    ?>
                        <div style="display: flex; flex-direction: column; align-items: center; width: 60px; margin: 0 10px;">
                            <!-- Bar -->
                            <div style="height: <?php echo $height; ?>px; width: 100%; background-color: <?php echo $barColor; ?>;"></div>
                            <!-- Value Label -->
                            <span style="margin-top: 5px; font-size: 12px; font-weight: bold;"><?php echo $rate; ?>%</span>
                            <!-- Treatment Name -->
                            <span style="margin-top: 5px; font-size: 10px; text-align: center; writing-mode: vertical-lr; transform: rotate(180deg);">
                                <?php echo $treatment; ?>
                            </span>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include('./constant/layout/footer.php'); ?>